export function showCountryAlert(country) {
    alert(`You have selected the country - ${country}`);
}
