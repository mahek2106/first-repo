export function getSelectedCountry(value) {
    if (!value) {
        return null;
    }
    return value;
}
